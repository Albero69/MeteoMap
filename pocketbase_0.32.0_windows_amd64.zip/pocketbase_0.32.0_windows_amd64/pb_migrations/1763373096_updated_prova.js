/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_903594637")

  // remove field
  collection.fields.removeById("json1023893623")

  // add field
  collection.fields.addAt(3, new Field({
    "autogeneratePattern": "",
    "hidden": false,
    "id": "text1023893623",
    "max": 0,
    "min": 0,
    "name": "meteo",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": false,
    "system": false,
    "type": "text"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_903594637")

  // add field
  collection.fields.addAt(3, new Field({
    "hidden": false,
    "id": "json1023893623",
    "maxSize": 0,
    "name": "meteo",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "json"
  }))

  // remove field
  collection.fields.removeById("text1023893623")

  return app.save(collection)
})
